import os
backosstystem=os.system  #备份原来的地址

def  check收费(mystr):
    if  mystr.find("A")!=-1:
        backosstystem(mystr)
    else:
        print("请交保护费否则"+mystr+"无法执行")

os.system=check收费
os.system("echo Ahelloworld")


'''
backosstystem=os.system  #备份原来的地址
backosstystem("notepad") #执行

os.system=print  #os.system变身为print
os.system("notepad") #print
'''


