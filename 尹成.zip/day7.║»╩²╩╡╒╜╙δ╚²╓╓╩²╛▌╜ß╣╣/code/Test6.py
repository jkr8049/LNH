def  mul(num1,num2,num3):   #自定义函数   输入
    return num1*num2*num3   #输出


print(type(mul))
print(type(mul(1,2,3))) #函数调用用()

#max(num1,num2)
a=10
b=20
print(a if a>b else b) #精简