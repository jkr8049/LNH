def  go():
    print("A")
    return  #return之后语句不会再被执行
    print("B")

#print(go)#go是一个函数名，代表地址
print(go())
print(type(go()))  # go()取决于输出返回值得类型