mylist={1,2,3,4,5,6}
print(1  in  mylist) #in用于判断存在
print(10 not in mylist) #not  in判断不存在


for  x  in mylist:
    print(x)