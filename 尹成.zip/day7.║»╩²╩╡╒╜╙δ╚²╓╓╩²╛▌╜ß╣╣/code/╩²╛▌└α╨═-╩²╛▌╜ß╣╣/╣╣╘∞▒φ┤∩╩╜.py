

mylist=[x*x   for  x  in range(10)]#列表构造表达式
print(mylist)

mylist=[1+x*2  for  x  in range(50)]
print(mylist)

mylist=[x*2  for  x  in range(50)]
print(mylist)