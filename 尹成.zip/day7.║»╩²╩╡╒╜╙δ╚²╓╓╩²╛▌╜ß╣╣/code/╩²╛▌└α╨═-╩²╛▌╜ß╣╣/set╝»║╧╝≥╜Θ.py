mylist=[1,1,1]
myset={1,1,1} #数据不可以重合
print(mylist)
print(myset)
print(type(myset))