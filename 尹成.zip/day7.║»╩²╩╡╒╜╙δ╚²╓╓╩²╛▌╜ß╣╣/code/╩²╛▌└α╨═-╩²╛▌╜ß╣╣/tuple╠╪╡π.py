
mytuple=(1,)  #python特例(1)是int  ()(1,)
print(mytuple)
print(type(mytuple))