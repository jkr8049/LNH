list=[1,2,3]
list[1]=10 #list可以修改
print(list)
for  i in range(len(list)):#索引循环
    print(list[i])