#函数地址变量，函数地址常量（规范）
def  add(num1,num2,num3):   #自定义函数   输入
    return num1+num2+num3   #输出

def  mul(num1,num2,num3):   #自定义函数   输入
    return num1*num2*num3   #输出
#print(add(1,2,5))
#print(mul(1,2,5))
'''
op=add  #op是一个函数地址变量，存储不同的函数地址
print(op(1,2,10))
op=mul
print(op(1,2,10))
'''
#软件规范不允许这样赋值，规范add是常量不允许被复制
add=mul
print(add(1,2,10))
