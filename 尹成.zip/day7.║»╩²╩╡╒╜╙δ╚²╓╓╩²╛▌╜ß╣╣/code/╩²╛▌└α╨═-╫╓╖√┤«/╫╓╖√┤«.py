print("notepad")
print(len("notepad")) #字符串长度为7
print("-----------------","notepad"[1]) #[]用于取出第几个字符
for  ch  in  "notepad": #遍历字符串的每一个字符
    print(ch)
for  i  in range(len("notepad")): #根据索引
    print("notepad"[i])
