mystr="cmd"
print(id(mystr))
print(mystr[0])
#mystr[0]='A'
#mystr="Amd"
print(id(mystr))
print(mystr)
#字符串可以调到新的字符串地址，但是不可以改变常量字符串