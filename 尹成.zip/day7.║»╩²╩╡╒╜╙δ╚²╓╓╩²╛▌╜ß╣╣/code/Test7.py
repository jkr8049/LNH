import time

def  cost():
    print("cost start")
    time.sleep(3)
    print("cost end")

print("start")
print(cost()) #cost执行完成之前，print("end")
print("end")