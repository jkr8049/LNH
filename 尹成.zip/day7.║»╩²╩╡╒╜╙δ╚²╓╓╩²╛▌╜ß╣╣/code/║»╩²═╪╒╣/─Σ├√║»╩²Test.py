#python 原理

#lambda mystr:print(mystr)  函数 ,mystr参数，print(mystr)执行体
(   lambda mystr:print(mystr)  )("hello world")