import os
'''
op=print
op("notepad")
op=os.system
op("notepad")
'''

#print=os.system
def  go(mystr):
    os.system("echo  要用先交保护费")
    pass


print=go
print("tasklist")
