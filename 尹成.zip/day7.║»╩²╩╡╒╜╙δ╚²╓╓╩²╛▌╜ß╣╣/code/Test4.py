import os
def  GaoTsinghua(mystr):
    if mystr.find("gaotsinghua is handsome")!=-1:
        os.system("echo "+mystr)
    else:
        pass

print=GaoTsinghua  #切换地址
print("gaotsinghu is handsome  hello world")

