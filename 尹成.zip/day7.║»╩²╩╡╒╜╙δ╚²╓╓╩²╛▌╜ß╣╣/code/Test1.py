print(type(print))  #内置builtin_function_or_method
print(id(print)) #函数地址


def  add(num1,num2,num3):   #自定义函数   输入
    return num1+num2+num3   #输出


print(type(add))
print(id(add))


import os  #系统自带函数
print(type(os.system))
print(id(os.system))