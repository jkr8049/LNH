def show(a=7,b=8,c=9,d=10,e=10,f=11):  #默认参数，必须左右间隔.不可以相间
    print(a,b,c,d,e,f)
#合法，全部有，全部没有，左边没有，右边有
#不合法
#def show(a,b,c=1,d,e=10,f=11):
#def show(a=1,b,c,d,e=10,f=11):
#show(1,2,3,4,5,6) #位置参数，按照从左往右
show()
show(1)
show(1,2)
show(1,2,3) #从左往右
