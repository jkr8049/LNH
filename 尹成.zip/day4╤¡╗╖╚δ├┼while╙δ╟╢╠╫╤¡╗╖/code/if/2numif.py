'''
x=10
num= 10 if x>18  else 20
print(num)
'''
#ages=10
#price=  20  if  ages>=16 else 10

import  os
os.system("calc")  if  3>12  else  os.system("notepad")