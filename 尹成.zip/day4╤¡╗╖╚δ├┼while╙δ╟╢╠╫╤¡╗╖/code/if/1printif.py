num=5
print("hello "  if num>5  else "world"  )

#  if bool() ->true  AAAAA.false  BBBBB
print("AAAA"  if bool(3)  else "BBBB"  )