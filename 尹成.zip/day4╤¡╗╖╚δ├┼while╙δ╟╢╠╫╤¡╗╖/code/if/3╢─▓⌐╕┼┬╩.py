#1-100
import  random
num=random.randint(1,100)
print("输了"  if  num<52 else "赢了")

