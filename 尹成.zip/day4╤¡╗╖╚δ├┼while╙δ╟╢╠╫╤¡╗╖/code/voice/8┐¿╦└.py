import os
import time
while -1:
    #os.system("notepad")#同步模式，一个程序执行结束，执行下一个
    os.system("start notepad")#异步模式
    #time.sleep(1)#暂停1秒