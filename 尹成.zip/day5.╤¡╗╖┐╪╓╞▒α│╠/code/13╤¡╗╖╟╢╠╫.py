for  i  in range(8): #i循环一次，j循环5次
    for  j  in range(6): #50次
        print(j, end="  ")
    print("---------------", i)