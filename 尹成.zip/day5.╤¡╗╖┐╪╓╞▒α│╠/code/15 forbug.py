
#for循环特点
for i  in  range(2,1,-1): #  a,b, step,  step>0 ,a<b   step<0 a>b
    print(i)