
'''

#循环的等价处理
num=0
while num<10:
    print(num)
    num+=1


for  i  in range(10):
    print(i)


'''

num=0
while True:
    if num>9:
        break
    print(num)
    num+=1



