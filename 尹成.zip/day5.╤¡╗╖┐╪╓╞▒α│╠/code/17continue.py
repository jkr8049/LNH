'''
for i  in range(100):
    if i==30:
        continue  #结束本次循环，本次循环contiune执行，后续本次循环后续代码不会执行
    print(i)

'''

'''
#筛选
for  i  in range(100):
    if i%2==1:
        continue
    print(i)

'''

for  i  in range(100):
    if i%2==0:
        break
    print(i)
