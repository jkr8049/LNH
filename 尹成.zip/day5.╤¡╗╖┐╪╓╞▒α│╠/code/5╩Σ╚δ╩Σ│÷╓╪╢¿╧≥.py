import os
cmd=input("cmd")
os.system(cmd)

#>写入文本覆盖
#>>增加模式，
#<输入
