#for  i  in range(100,0,-2):
#    print(i)

#for  i  in range(100): 100次，从0开始一直到99
#for i in range(0, 100, 2):0-100,每次步长为2
#range(min,max, step)不包含ｍａｘ　　＜ｍａｘ
#range(max,min, step)不包含ｍｉｎ　　＞ｍｉｎ

for  i  in  range(80,10,0): #0,1  min  max  step
    print(i)