'''
for i  in range(100): #for仅仅适用整数
    print(i)
else:
    print("out",i)#99恰好即将跳出循环
'''

for i  in range(100): #for仅仅适用整数
    print(i)
else:
    print("out",i)#99恰好即将跳出循环