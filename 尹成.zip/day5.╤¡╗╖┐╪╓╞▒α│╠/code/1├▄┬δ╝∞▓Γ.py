password=input("请输入密码")
'''
while "123456"!=password:
    password=input("密码错误，请重新输入") #循环体
print("密码正确") #循环跳出

'''
while "123456"!=password:
    password=input("密码错误，请重新输入") #循环体
else:
    print("密码正确") #循环终止条件


