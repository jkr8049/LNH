num=eval(input("输入数据数量")) #读取第一个值=10
print(num)
maxdata=eval(input("data"))
print(maxdata)
for  i  in range(num-1): #循环9次
    data=eval(input("data"))
    if  data>maxdata:
        maxdata=data
    print(data)
print("max",maxdata)
