import turtle

turtle.showturtle()
turtle.pensize(3)

step=20


for  i  in range(8):
    for j in range(8):
        turtle.penup()
        turtle.goto(i*step,j*step)
        turtle.pendown()
        turtle.begin_fill()


        for  k  in range(4):
            turtle.forward(step)
            turtle.right(90)


        if  (i+j)%2==0: #总结提炼
            turtle.color("white")
        else:
            turtle.color("black")

            
        turtle.end_fill()



turtle.done()