num=eval(input("输入数据数量")) #读取第一个值=10
print(num)
maxdata=eval(input("data"))  #100   #90
nextdata=eval(input("data"))  #90   #100

#max >nextmax 确保max  >nextmax
if  maxdata<nextdata:  #max90  <  next100
    temp=maxdata      #temp=90,max=100
    maxdata=nextdata  #max=100  next=100
    nextdata=temp      #next=90

for  i in range(num-2): #循环8次
    x = eval(input("data"))
    if x > maxdata:
        nextdata = maxdata
        maxdata = x
    elif x < maxdata:
        if x < nextdata:
            pass
        elif x > nextdata:
            nextdata = x
print(maxdata)
print(nextdata)

