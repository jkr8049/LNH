

'''
#2017   2027-2031
money=10000
for  year  in range(1,11):  #循环10年，每年递增
    money=money*1.05


money1=money  #每年增长
money2=money1*1.05
money3=money2*1.05
money4=money3*1.05


lastmoney=money1+money2+money3+money4 #四年叠加
print(lastmoney)
'''


'''
money=10000
for  year  in range(1,11):  #循环10年，每年递增
    money=money*1.05

lastmoney=money
for  year  in range(1,4):  #循环3次
    money=money*1.05
    lastmoney+=money

print(lastmoney)

'''

'''

money=10000
year=1
while  year<11:
    money=money*1.05
    year=year+1

lastmoney=money
year=1
while  year<4:
    money=money*1.05
    year=year+1
    lastmoney+=money


print(lastmoney)
'''


money=10000
year=1
while  True:
    money=money*1.05
    year=year+1
    if year==10:
        break


lastmoney=money
year=1
while  True:
    money=money*1.05
    year=year+1
    lastmoney+=money
    if  year==4:
        break


print(lastmoney)




