a=10
b=20
#a,b=b,a  #交换数据

temp=a  #交换数据
a=b
b=temp
print(a,b)