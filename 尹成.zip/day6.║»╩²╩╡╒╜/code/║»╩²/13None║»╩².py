def go():
    print("go")
    return


print(go()) #没有返回值(没有return,有return没有返回数据)，默认返回值为None