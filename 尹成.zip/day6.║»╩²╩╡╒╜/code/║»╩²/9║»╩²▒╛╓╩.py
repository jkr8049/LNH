def  add(num1,num2):
    return num1+num2

print(id(add)) #函数的地址
print(type(add)) #函数的类型