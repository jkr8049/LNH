def  Test():
    def TestX():
        print("hello world")
    TestX()

Test()

#函数可以无限嵌套