def add(num1,num2):
    return num1+num2

#print(type(add(1,2)))

print(add(add(1,2),add(1,1)))#返回值当作参数使用