'''
num=190
mystr="何丰成的女神有%d个备胎"%(num) #格式化， num当作整数，
print(mystr)

'''
num=190
money=4980.56
newmoney=3456.67
mystr="何丰成的女神有%d个备胎,他花了%.2f元给女神买了一个手机,女神感动的接下手机，说你是个好人，然后另外一个备胎花了%.2f元，租了一辆奔驰，然后买了一束花，然后女神陪她睡了"%(num,money,newmoney) #格式化， num当作整数，
print(mystr)



