print("hello world")
print('hello python')
print("""程序猿的读书历程：
x 语言入门 —>
 x 语言应用实践 —>
  x 语言高阶编程 —>
   x 语言的科学与艺术 —>
    编程之美 —>
     编程之道 —>
      编程之禅—>
      颈椎病康复指南""")
