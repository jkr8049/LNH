ch1='我'
ch2='H'
print(ord(ch1)) #只能处理单个字符
print(ord(ch2))
#python  ‘’用于字符  ，“”字符串,"""多行字符串"""