

#  "calc"
print("\"calc\"") #   \"代表字符串中的"
print("ABCD\nEFG") # \n不显示，换行作用
print("C:\\Users\\Tsinghua-yincheng\\Desktop\\tools")