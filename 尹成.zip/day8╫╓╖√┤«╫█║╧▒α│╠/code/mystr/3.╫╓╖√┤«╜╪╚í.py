mystr="""生活中程序猿的真实写照、
一款游戏一包烟，一台电脑一下午。
一盒泡面一壶水，一顿能管一整天"""
print(mystr[0]) #生
print(mystr[1])  #活
print(mystr[-1])  #天
print(mystr[:]) #整个字符串
print(mystr[2:]) #从编号为2的开始截取一直到最后
print(mystr[:6]) #从开头到编号为 6 的字符，0-5
print(mystr[3:6])
print(mystr[12:20]) #换行也是一个字符
print(mystr[-15:-8])#负索引