'''
mystr="calc"
print(mystr[1])
#mystr[1]='X'  字符串单个元素不可以赋值
mystr="xalc"  #字符串可以赋值新的常量字符串地址
'''
mystr="112340"
print(mystr[3:4])#3
mystr=mystr[3:4]
print(mystr) #字符串除非赋值，不会改变
