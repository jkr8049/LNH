print(" ab c ".strip()) #前后去掉空格
print(" ab c ".rstrip()) #去掉右边
print(" ab c ".lstrip()) #去掉左边