print("abc".upper()) #小写转大写
print("Abc".lower()) #大写转小写

print(max("sadsadsax")) #取出编号最大的字符
print(min("sadsadsax")) #取出编号最大=小的字符

#  '97' a  '65'  B