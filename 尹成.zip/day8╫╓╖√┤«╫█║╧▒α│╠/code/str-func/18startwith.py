print("逗逼is you".startswith("1逗")) #判断是否开头

mystr="hello world"
mystr1="HELLO world"
print(mystr.swapcase())
mystr=mystr.swapcase()
print(mystr.swapcase())#切换，不会改变原来的

print(mystr1.swapcase())
mystr1=mystr1.swapcase()
print(mystr1.swapcase())


print("123".zfill(40))#金融数据

