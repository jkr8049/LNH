mystr="A1021879743 # 1021879743 # www.1021879743@qq.com"
mylist=mystr.split(" # ") #切割，按照 # 返回列表
print(mylist)

mystr="88548 n小姐 女 22 162"
mylist=mystr.split(" ",2) #切割，按照 # 返回列表
print(mylist)


