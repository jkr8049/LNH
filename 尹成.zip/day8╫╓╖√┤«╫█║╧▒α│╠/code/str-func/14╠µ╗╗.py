mystr="hello  123  hello 123"
print(mystr.replace("123","python"))#替换
print(mystr.replace("123","python",1))#替换,1限制次数
print(mystr)