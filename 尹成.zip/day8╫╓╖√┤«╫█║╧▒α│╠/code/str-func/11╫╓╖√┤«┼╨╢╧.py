print("hello123我".isalnum()) #判断字符串是否由数字字母组成，汉字当作字母
print("13213213213a".isdigit()) #判断字符串是否纯数字
print("advcf我".isalpha()) #判断字符串纯字母
print("abc我".islower()) #判断都是小写，#汉字没有大小写
print("ABC我".isupper()) #判断都是大写
print(" ".isspace()) #判断字符串是否纯空格组成
print("hello".istitle()) #istitle是否首字母大写且其他字母小写
print("0x109".isdecimal()) #判断进制
