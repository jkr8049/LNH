
file= input("输入一个文件名称")
print(file.endswith(".txt")) #判断文件是否以某个字符串为结束
