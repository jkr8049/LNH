
#evel只能处理字符串，字符串的数值或者表达式
print(eval("12.3"))
print(eval("18.9"))
print(eval("12"))
print(eval("2.3*2"))
print(eval(2.3*2))#只能处理字符串